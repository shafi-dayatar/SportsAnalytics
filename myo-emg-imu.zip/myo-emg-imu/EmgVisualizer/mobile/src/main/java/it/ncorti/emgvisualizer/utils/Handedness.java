package it.ncorti.emgvisualizer.utils;

public enum Handedness {
	Left,Right;
}
