package it.ncorti.emgvisualizer.DataAnalysis;

public enum Stroke {
    BACKSLICE, BACKTOP, FORESLICE, FORETOP , NOSWING, RUNNING, SERVE, WALKING ;
}
