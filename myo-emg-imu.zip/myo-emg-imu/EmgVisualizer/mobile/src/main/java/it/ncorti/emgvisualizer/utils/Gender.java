package it.ncorti.emgvisualizer.utils;

import java.io.Serializable;

public enum Gender implements Serializable{
	Male,Female,Other;
}
