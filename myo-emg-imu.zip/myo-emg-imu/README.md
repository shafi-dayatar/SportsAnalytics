# myo-emg-visualizer
A simple Android app to display emg raw data from Myo device
